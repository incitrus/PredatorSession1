# Spammer-Grab
Spams GAC (Grab Activation Code) SMS to a phone number repeatedly per 60 second. "Spammer" uses Grab passenger API to make the GAC sms sent. "Spammer" is tested under Python 2.7

# How to use?
Just type 'python Spammer.py -h' to show the help message.

# Installation ( For Debian and Ubuntu )
1. `sudo apt-get update` - To get information on the newest versions of packages and their dependencies.
2. `sudo apt install python2.7 python-pip` - To install python2
3. `sudo apt install git` - To install git
4. `git clone https://github.com/Noxturnix/Spammer-Grab` - To clone a FIXED version
5. `cd Spammer-Grab` - To enter the directory of this git
6. `pip2 install requests` - To install the request module

Example of command is : python2 spammer.py [Phone Number]
For Help : python2 spammer.py -h

# Me
E-Mail: p4kl0nc4t@obsidiancyberteam.id
Do not hesitate to contact me :)
